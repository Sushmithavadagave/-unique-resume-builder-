
# Easy-Resume
An Easy Resume (online resume builder) is a software developed to simplify the  task of creating a resume for individuals. The application provides an effective  means of designing desired resume in fact a professional looking resume. The  system is flexible to be used and reduces the need of thinking and designing an  appropriate resume according to qualifications. Usually individuals get confused  while creating a resume especially for a novice person such as graduate students.  They don’t get a clear idea of what things and information must be included in a  resume. Hence the system is developed to provide them an easy way for creating  a professional looking resume. This project is user-friendly and requires minimum human intervention.  Individuals just have to fill up a form that specifies questions from all required  fields such as personal questions, educational, qualities, interest, skills and so on.  The answers provided by the users are stored and the system automatically  generates a well-structured resume. Users have option to create resume in any  format and file.

## Interface


https://github.com/ChaitanyaYeole/EasyResume-Java/assets/69446108/07945d19-81a8-4ae9-8cf7-521dd411b1bf

## Databases

![user](https://github.com/ChaitanyaYeole/EasyResume-Java/assets/69446108/f2fa1c88-3f36-499c-81d8-f69102deea62)
![resumeContent](https://github.com/ChaitanyaYeole/EasyResume-Java/assets/69446108/b6d5fd63-d6b8-42b3-b34d-ba9b80b2dc92)
![releation](https://github.com/ChaitanyaYeole/EasyResume-Java/assets/69446108/1bcb0d08-eb8d-47d7-b6de-a8d583f791e4)


## Connect me



[![github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ChaitanyaYeole)
[![twitter](https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white)](https://twitter.com/chaitanyayeole7)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/chaitnyayeole/)



## Feedback

If you having any feedback or having any problem in using or running program do comment down your thoughts and querys.


## License

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)


